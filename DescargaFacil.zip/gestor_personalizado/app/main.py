"""Descarga Fácil 0.4 - Qt desktop client and local Edge extension bridge."""
import json, os, sys, time, uuid, queue, threading, urllib.parse, urllib.request, subprocess, re, mimetypes, sqlite3
from concurrent.futures import Future
from email.message import Message
from segmented import (download as segmented_download, request as download_request,
    Paused, Cancelled, direct_dropbox_url, is_dropbox_url, validate_dropbox_response)
import youtube
from pathlib import Path
from http.client import HTTPException
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from updater import check_app_release, download_installer
from PySide6.QtCore import Qt, QTimer, Signal, QObject
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QLabel,
    QPushButton, QLineEdit, QTableWidget, QTableWidgetItem, QHeaderView, QFrame,
    QFileDialog, QDialog, QCheckBox, QMessageBox, QProgressBar, QAbstractItemView, QMenu, QSpinBox)

if sys.platform == 'win32':
    import winreg

VERSION='0.6.6'
GITHUB_REPOSITORY='moisesh808-byte/Descarga-Facil'
STARTUP_KEY=r'Software\Microsoft\Windows\CurrentVersion\Run'
STARTUP_VALUE='DescargaFacil'
ROOT=Path(os.getenv('APPDATA',str(Path.home()))) / 'GestorPersonal' # Preserve v0.3 Edge token.
ROOT.mkdir(parents=True,exist_ok=True)
HISTORY_DB=ROOT/'history.sqlite3'
CONFIG=ROOT/'settings.json'
DEFAULT={'capture':True,'videos':True,'notifications':True,'download_dir':str(Path.home()/'Downloads'),'connections':8,'acceleration':True}
try: settings={**DEFAULT,**json.loads(CONFIG.read_text(encoding='utf-8'))}
except (OSError,ValueError): settings=DEFAULT.copy()
def save(): CONFIG.write_text(json.dumps(settings,indent=2),encoding='utf-8')
save()
TOKEN_FILE=ROOT/'bridge_token.txt'
if TOKEN_FILE.exists(): TOKEN=TOKEN_FILE.read_text(encoding='utf-8').strip()
else:
    TOKEN=uuid.uuid4().hex
    TOKEN_FILE.write_text(TOKEN,encoding='utf-8')

def windows_startup_enabled():
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_KEY) as key:
            winreg.QueryValueEx(key, STARTUP_VALUE)
    except FileNotFoundError:
        return False
    return True

def set_windows_startup(enabled):
    if enabled:
        command = f'"{sys.executable}"'
        if not getattr(sys, 'frozen', False):
            command += f' "{Path(__file__).resolve()}"'
        with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, STARTUP_KEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, STARTUP_VALUE, 0, winreg.REG_SZ, command + ' --startup')
        return
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, STARTUP_KEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, STARTUP_VALUE)
    except FileNotFoundError:
        pass

def safe_filename(value):
    value = str(value).replace('\\', '/').split('/')[-1].strip().strip('.')
    value = ''.join(ch for ch in value if ch not in '<>:"/\\|?*\x00\r\n' and ord(ch) >= 32)
    return value[:220] or 'descarga'

def response_filename(headers, response_url, fallback, first_bytes):
    # Content-Disposition filename* (RFC 5987) and filename, including quoted names.
    cd = headers.get('Content-Disposition', '')
    if cd:
        msg = Message()
        msg['Content-Disposition'] = cd
        name = msg.get_filename()
        if name:
            if isinstance(name, tuple):
                from email.utils import collapse_rfc2231_value
                name = collapse_rfc2231_value(name)
            candidate = safe_filename(name)
        else:
            candidate = ''
    else:
        candidate = ''
    if not candidate:
        candidate = safe_filename(urllib.parse.unquote(urllib.parse.urlparse(response_url).path.rsplit('/',1)[-1]) or fallback)
    suffix = Path(candidate).suffix.lower()
    mime = headers.get_content_type() if hasattr(headers, 'get_content_type') else headers.get('Content-Type','').split(';')[0].lower()
    # Magic signatures take precedence for ZIP downloads with missing or generic names.
    if first_bytes.startswith(b'PK\x03\x04') or first_bytes.startswith(b'PK\x05\x06') or first_bytes.startswith(b'PK\x07\x08'):
        if suffix not in ('.zip','.jar','.apk','.docx','.xlsx','.pptx','.odt','.ods','.epub','.cbz'):
            candidate = str(Path(candidate).with_suffix('.zip')) if suffix in ('','.bin','.dat','.download','.tmp') else candidate
    elif not suffix:
        common = {'application/pdf':'.pdf','video/mp4':'.mp4','video/webm':'.webm',
                  'image/jpeg':'.jpg','image/png':'.png','audio/mpeg':'.mp3',
                  'application/x-7z-compressed':'.7z','application/x-rar-compressed':'.rar',
                  'application/zip':'.zip','application/x-zip-compressed':'.zip'}
        ext = common.get(mime)
        if ext: candidate += ext
    return safe_filename(candidate)

STYLE='''
QWidget {background:#0d1019;color:#e9edfa;font:10pt "Segoe UI";}
QMainWindow {background:#0d1019;}
QFrame#sidebar {background:#121724;border-right:1px solid #263044;}
QFrame#panel {background:#171d2b;border:1px solid #283145;border-radius:16px;}
QLabel#brand {font-size:21pt;font-weight:800;color:#f5f7ff;}
QLabel#muted {color:#8994aa;}
QLabel#metric {font-size:20pt;font-weight:750;color:#f4f6ff;}
QPushButton {background:#222b3e;border:1px solid #36415a;border-radius:10px;padding:10px 15px;font-weight:600;}
QPushButton:hover {background:#34415c;}
QPushButton#primary {background:#5268ef;border:1px solid #7081ff;color:white;}
QPushButton#primary:hover {background:#697cfb;}
QPushButton#nav {background:transparent;border:0;text-align:left;padding:12px 15px;color:#aab5cd;}
QPushButton#nav:hover {background:#202a40;color:white;}
QPushButton#navActive {background:#263455;border:1px solid #354d7e;text-align:left;padding:12px 15px;color:#cbdcff;}
QLineEdit {background:#171e2e;border:1px solid #35425c;border-radius:10px;padding:10px;color:#f3f6ff;}
QTableWidget {background:#141a27;alternate-background-color:#192132;border:1px solid #293247;border-radius:12px;gridline-color:transparent;selection-background-color:#283b61;}
QHeaderView::section {background:#1c2535;color:#aab6cc;border:0;border-bottom:1px solid #35405a;padding:12px;font-weight:700;}
QTableWidget::item {padding:7px;}
QCheckBox {spacing:10px;}
QProgressBar {border:0;background:#273248;border-radius:5px;height:10px;text-align:center;color:transparent;}
QProgressBar::chunk {background:#17834e;border-radius:5px;}
'''

def label(text,kind=None):
    x=QLabel(text)
    if kind:x.setObjectName(kind)
    return x

def panel(title, value):
    p=QFrame();p.setObjectName('panel');v=QVBoxLayout(p);v.setContentsMargins(18,14,18,14)
    v.addWidget(label(title,'muted'));n=label(value,'metric');v.addWidget(n)
    return p,n

class Main(QMainWindow):
    def __init__(self):
        super().__init__();self.setWindowTitle('Descarga Fácil — v'+VERSION)
        self.resize(1200,750);self.setMinimumSize(950,590)
        from PySide6.QtGui import QIcon
        self.setWindowIcon(QIcon(str(Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))/'icon.ico')))
        self.events=queue.Queue();self.jobs={};self.controls={};self.active_filter='Todas'
        self.db=sqlite3.connect(str(HISTORY_DB),timeout=15)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS downloads (id TEXT PRIMARY KEY, payload TEXT NOT NULL, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)')
        self.db.commit()
        self.last_saved={}
        self.restore_history()
        central=QWidget();self.setCentralWidget(central);outer=QHBoxLayout(central);outer.setContentsMargins(0,0,0,0);outer.setSpacing(0)
        sidebar=QFrame();sidebar.setObjectName('sidebar');sidebar.setFixedWidth(220);side=QVBoxLayout(sidebar);side.setContentsMargins(15,28,15,20);side.setSpacing(8)
        side.addWidget(label('⬇  Descarga Fácil','brand'));side.addWidget(label('DOWNLOAD MANAGER  ·  v'+VERSION,'muted'));side.addSpacing(25)
        self.nav={}
        for name, emoji in (
            ('Todas', '▦'),
            ('Completadas', '✓'),
            ('En progreso', '◷'),
            ('Programas', '⬡'),
        ):
            b=QPushButton(f'{emoji}    {name}');b.setObjectName('navActive' if name=='Todas' else 'nav')
            b.clicked.connect(lambda checked=False,n=name:self.set_filter(n));side.addWidget(b);self.nav[name]=b
        side.addStretch();side.addWidget(label('●  Integración Edge: puerto 8765','muted'));side.addWidget(label('La extensión mantiene su token','muted'))
        outer.addWidget(sidebar)
        main=QWidget();body=QVBoxLayout(main);body.setContentsMargins(25,23,25,20);body.setSpacing(18)
        top=QHBoxLayout();heading=QVBoxLayout();heading.addWidget(label('Panel de descargas','brand'));heading.addWidget(label('Controlá tus archivos desde un solo lugar','muted'));top.addLayout(heading);top.addStretch()
        add=QPushButton('＋  Agregar URL');add.setObjectName('primary');add.clicked.connect(self.add_url);top.addWidget(add)
        options=QPushButton('⚙  Ajustes');options.clicked.connect(self.preferences);top.addWidget(options)
        self.updates=QPushButton('↻  Buscar actualizaciones')
        updates_menu=QMenu(self.updates)
        updates_menu.addAction('Buscar versión de Descarga Fácil', self.check_app_updates)
        updates_menu.addAction('Actualizar motor de YouTube', self.check_engine_updates)
        self.updates.setMenu(updates_menu);top.addWidget(self.updates);body.addLayout(top)
        cards=QHBoxLayout();cards.setSpacing(13)
        a,self.total_label=panel('TOTAL DE DESCARGAS','0');b,self.running_label=panel('EN PROGRESO','0');c,self.done_label=panel('COMPLETADAS','0');d,self.speed_label=panel('VELOCIDAD ACTUAL','0 MB/s')
        for p in (a,b,c,d):cards.addWidget(p)
        body.addLayout(cards)
        searchrow=QHBoxLayout();searchrow.addWidget(label('Archivos recientes','brand'));searchrow.addStretch()
        self.search=QLineEdit();self.search.setPlaceholderText('⌕  Buscar archivos...');self.search.setFixedWidth(270);self.search.textChanged.connect(self.refresh);searchrow.addWidget(self.search)
        clear=QPushButton('Limpiar historial');clear.clicked.connect(self.clear_history);searchrow.addWidget(clear)
        body.addLayout(searchrow)
        self.table=QTableWidget(0,5);self.table.setHorizontalHeaderLabels(['ARCHIVO','TAMAÑO','ESTADO','PROGRESO','VELOCIDAD'])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows);self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True);self.table.verticalHeader().hide();self.table.verticalHeader().setDefaultSectionSize(52)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.download_context_menu)
        self.table.cellDoubleClicked.connect(lambda row, col: self.open_download_folder(row))
        self.visible_jobs=[]
        self.table.horizontalHeader().setSectionResizeMode(0,QHeaderView.Stretch)
        for i,w in [(1,100),(2,135),(3,170),(4,110)]:self.table.setColumnWidth(i,w)
        body.addWidget(self.table,1)
        footer=QHBoxLayout();self.status=label('Listo. Esperando descargas desde Edge.','muted');footer.addWidget(self.status);footer.addStretch()
        footer.addWidget(label('Descarga Fácil  ·  Windows 11','muted'));body.addLayout(footer)
        outer.addWidget(main,1)
        self.timer=QTimer(self);self.timer.timeout.connect(self.flush);self.timer.start(120)
        self.refresh()
        threading.Thread(target=self.server,daemon=True).start()
    def restore_history(self):
        """Load local history; an interrupted transfer must never be marked active."""
        for (raw,) in self.db.execute('SELECT payload FROM downloads ORDER BY updated_at ASC'):
            try:
                job=json.loads(raw)
                if not isinstance(job,dict) or not job.get('id') or not job.get('url'):continue
                job.setdefault('name','descarga');job.setdefault('size','—')
                job.setdefault('progress',0);job.setdefault('path','')
                job['bps']=0;job['speed']='—'
                if job.get('status') in ('Descargando','En cola','Pausando...','Cancelando...'):
                    job['status']='Pausado' if job.get('status')!='Cancelando...' else 'Cancelado'
                self.jobs[job['id']]=job
                self.controls[job['id']]={'pause':threading.Event(),'cancel':threading.Event()}
            except (ValueError,TypeError):continue
        # Persist recovered state so subsequent starts also show paused, not active.
        self.persist_history(force=True)

    def persist_history(self,force=False):
        """SQLite writes are serialized on the Qt main thread."""
        now=time.monotonic()
        rows=[]
        for job in self.jobs.values():
            ident=job['id'];payload=json.dumps(job,ensure_ascii=False)
            previous=self.last_saved.get(ident)
            if not force and previous and previous[0]==payload:continue
            if not force and previous and now-previous[1]<0.8 and job.get('status')=='Descargando':continue
            rows.append((ident,payload))
        if rows:
            with self.db:
                self.db.executemany('INSERT INTO downloads(id,payload,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) '
                                    'ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,updated_at=CURRENT_TIMESTAMP',rows)
            for ident,payload in rows:
                self.last_saved[ident]=(payload,now)

    def clear_history(self):
        if any(j['status'] in ('Descargando','En cola','Pausando...','Cancelando...') for j in self.jobs.values()):
            QMessageBox.information(self,'Historial','Pausá o terminá las descargas activas antes de limpiar el historial.')
            return
        if QMessageBox.question(self,'Limpiar historial',
                '¿Eliminar las entradas del historial? Los archivos descargados NO se borrarán.',
                QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
        with self.db:self.db.execute('DELETE FROM downloads')
        self.jobs.clear();self.controls.clear();self.last_saved.clear();self.refresh()

    def closeEvent(self,event):
        if not self.updates.isEnabled():
            QMessageBox.information(self, 'Actualizaciones', 'Esperá a que termine la búsqueda de actualizaciones.')
            event.ignore()
            return
        # Workers are daemon threads. The persisted state will be paused on restart;
        # partial range metadata is retained by the segmented downloader.
        for control in self.controls.values():control['pause'].set()
        for control in self.controls.values():
            video_worker = control.get('video_worker')
            if video_worker:
                video_worker.join(timeout=3)
        self.closing = True
        self.flush()
        self.persist_history(force=True)
        self.db.close()
        super().closeEvent(event)

    def set_filter(self,name):
        self.active_filter=name
        for n,b in self.nav.items():b.setObjectName('navActive' if n==name else 'nav');b.style().unpolish(b);b.style().polish(b)
        self.refresh()
    def category(self,name):
        suffix=Path(name).suffix.lower()
        if suffix in ('.mp4','.mkv','.mov','.webm','.avi'):return 'Videos'
        if suffix in ('.mp3','.wav','.flac','.aac','.ogg'):return 'Música'
        if suffix in ('.png','.jpg','.jpeg','.webp','.gif','.svg'):return 'Imágenes'
        if suffix in ('.pdf','.docx','.doc','.txt','.xlsx','.pptx'):return 'Documentos'
        if suffix in ('.exe','.msi','.apk','.zip','.rar','.7z'):return 'Programas'
        return 'Otros'
    def visible(self,job):
        f=self.active_filter
        return (f=='Todas' or f==self.category(job['name']) or (f=='Completadas' and job['status']=='Completado') or (f=='En progreso' and job['status'] in ('En cola','Descargando','Pausado'))) and self.search.text().lower() in job['name'].lower()
    def refresh(self):
        items=[j for j in self.jobs.values() if self.visible(j)]
        self.visible_jobs=items
        self.table.setRowCount(len(items))
        for row,j in enumerate(items):
            for col,value in enumerate((j['name'],j['size'],j['status'],'',j['speed'])):
                it=QTableWidgetItem(str(value));it.setToolTip(j.get('path',''));self.table.setItem(row,col,it)
            progress=QProgressBar();progress.setValue(j['progress']);progress.setFormat(f"{j['progress']}%")
            progress.setStyleSheet('QProgressBar {text-align:center;color:#e9edfa;}')
            self.table.setCellWidget(row,3,progress)
        self.total_label.setText(str(len(self.jobs)))
        self.running_label.setText(str(sum(j['status']=='Descargando' for j in self.jobs.values())))
        self.done_label.setText(str(sum(j['status']=='Completado' for j in self.jobs.values())))
        self.speed_label.setText(f"{sum(j['bps'] for j in self.jobs.values() if j['status']=='Descargando')/1048576:.1f} MB/s")
    def open_download_folder(self, row):
        """Open the actual destination folder, selecting the completed file when possible."""
        if row < 0 or row >= len(self.visible_jobs):
            return
        job=self.visible_jobs[row]
        path=Path(job.get('path') or settings['download_dir'])
        if job.get('path') and path.is_file():
            try:
                if sys.platform == 'win32':
                    subprocess.Popen(['explorer.exe', '/select,', str(path)])
                elif sys.platform == 'darwin':
                    subprocess.Popen(['open', '-R', str(path)])
                else:
                    subprocess.Popen(['xdg-open', str(path.parent)])
                return
            except OSError:
                pass
        folder=path if path.is_dir() else path.parent
        if not folder.is_dir():
            folder=Path(settings['download_dir'])
        if not folder.is_dir():
            QMessageBox.warning(self,'Carpeta no encontrada','La carpeta de esta descarga todavía no existe.')
            return
        try:
            if sys.platform=='win32':os.startfile(str(folder))
            elif sys.platform=='darwin':subprocess.Popen(['open',str(folder)])
            else:subprocess.Popen(['xdg-open',str(folder)])
        except (OSError,AttributeError) as exc:
            QMessageBox.warning(self,'No se pudo abrir la carpeta',str(exc))

    def download_context_menu(self, position):
        row=self.table.rowAt(position.y())
        if row<0 or row>=len(self.visible_jobs):return
        job=self.visible_jobs[row];ident=job['id'];state=job['status']
        menu=QMenu(self)
        pause=menu.addAction('⏸  Pausar descarga');pause.setEnabled(state in ('En cola','Descargando'))
        resume=menu.addAction('▶  Reanudar descarga');resume.setEnabled(state=='Pausado')
        folder=menu.addAction('📁  Abrir carpeta de descarga')
        segments=menu.addAction('Ver conexiones de descarga')
        menu.addSeparator()
        cancel=menu.addAction('✕  Cancelar descarga');cancel.setEnabled(state in ('En cola','Descargando','Pausado'))
        selected=menu.exec(self.table.viewport().mapToGlobal(position))
        if selected==pause:self.pause_download(ident)
        elif selected==resume:self.resume_download(ident)
        elif selected==folder:self.open_download_folder(row)
        elif selected==segments:self.show_download_segments(ident)
        elif selected==cancel:self.cancel_download(ident)

    def show_download_segments(self, ident):
        dialog = QDialog(self)
        dialog.setWindowTitle('Conexiones de descarga')
        dialog.resize(600, 380)
        layout = QVBoxLayout(dialog)
        filename = label('')
        filename.setTextFormat(Qt.PlainText)
        filename.setWordWrap(True)
        status = label('', 'muted')
        status.setWordWrap(True)
        layout.addWidget(filename)
        layout.addWidget(status)
        table = QTableWidget(0, 3)
        table.setHorizontalHeaderLabels(['Conexión', 'Descargado', 'Progreso'])
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSelectionMode(QAbstractItemView.NoSelection)
        table.verticalHeader().hide()
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(table)
        close = QPushButton('Cerrar')
        close.clicked.connect(dialog.accept)
        layout.addWidget(close)
        previous = None

        def refresh_segments():
            nonlocal previous
            job = self.jobs.get(ident)
            if job is None:
                dialog.reject()
                return
            segments = job.get('segments', ())
            state = job['status']
            current = (job['name'], state, segments)
            if current == previous:
                return
            previous = current
            filename.setText(job['name'])
            if segments:
                status.setText(f"{len(segments)} {'conexión' if len(segments) == 1 else 'conexiones'} · {state}")
            elif job.get('video_format'):
                status.setText('El motor de YouTube informa el progreso total.')
            elif state in ('En cola', 'Descargando'):
                status.setText('Esperando los datos de las conexiones…')
            else:
                status.setText('Esta descarga no tiene datos por conexión.')

            table.setRowCount(len(segments))
            for row, (received, total) in enumerate(segments):
                transferred = f'{received:,} bytes'
                if total:
                    transferred += f' / {total:,}'
                table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
                table.setItem(row, 1, QTableWidgetItem(transferred))
                bar = QProgressBar()
                bar.setStyleSheet('QProgressBar {color:#e9edfa;}')
                if total:
                    percent = received * 100 // total
                    bar.setValue(percent)
                    bar.setFormat(f'{percent}%')
                elif state == 'Completado':
                    bar.setValue(100)
                else:
                    bar.setFormat('Tamaño desconocido')
                    bar.setValue(0)
                table.setCellWidget(row, 2, bar)

        refresh_segments()
        timer = QTimer(dialog)
        timer.timeout.connect(refresh_segments)
        timer.start(250)
        dialog.exec()
        timer.stop()
        dialog.deleteLater()

    def pause_download(self,ident):
        control=self.controls.get(ident)
        if control:
            control['pause'].set()
            self.jobs[ident]['status']='Pausando...';self.persist_history(force=True);self.refresh()

    def resume_download(self,ident):
        control=self.controls.get(ident)
        if not control or self.jobs[ident]['status']!='Pausado':return
        control['pause'].clear();control['cancel'].clear()
        self.jobs[ident].pop('segments', None)
        self.jobs[ident]['status']='En cola';self.persist_history(force=True);self.refresh()
        self.start_worker(ident)

    def cancel_download(self,ident):
        job=self.jobs.get(ident)
        if not job:return
        choice=QMessageBox.question(self,'Cancelar descarga',
            '¿Cancelar esta descarga y eliminar los archivos parciales?',
            QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        if choice!=QMessageBox.Yes:return
        control=self.controls.get(ident)
        if control:
            control['cancel'].set()
            if job['status']=='Pausado':
                self.cleanup_parts(job)
                job.update(status='Cancelado',bps=0,speed='—');self.persist_history(force=True);self.refresh()
            else:
                job['status']='Cancelando...';self.persist_history(force=True);self.refresh()

    def cleanup_parts(self,job):
        if job.get('path'):
            for suffix in ('.part','.part.json'):
                Path(job['path']+suffix).unlink(missing_ok=True)

    def flush(self):
        changed=False
        for _ in range(150):
            try:typ,data=self.events.get_nowait()
            except queue.Empty:break
            if typ=='job':self.jobs[data['id']]=data;changed=True
            elif typ=='status':self.status.setText(data)
            elif typ=='update':self.show_update_result(data)
            elif typ=='update_progress':
                self.status.setText(f'Descargando actualización de Descarga Fácil · {data}%')
            elif typ=='installer':self.open_update_installer(*data)
            elif typ=='download':
                url, transfer_url, video_format, result = data
                if not result.set_running_or_notify_cancel():
                    continue
                try:
                    if getattr(self,'closing',False):
                        raise RuntimeError('La aplicación se está cerrando.')
                    self.download(url,transfer_url,video_format)
                except Exception as exc:
                    result.set_exception(exc)
                else:
                    result.set_result(None)
        if changed:
            self.persist_history()
            self.refresh()
    def add_url(self):
        dialog=QDialog(self);dialog.setWindowTitle('Nueva descarga');dialog.resize(550,145);v=QVBoxLayout(dialog)
        v.addWidget(label('Pegá el enlace HTTP o HTTPS:'));entry=QLineEdit();entry.setPlaceholderText('https://ejemplo.com/archivo.zip');v.addWidget(entry)
        btn=QPushButton('Descargar con Descarga Fácil');btn.setObjectName('primary')
        btn.clicked.connect(lambda:(self.download(entry.text()),dialog.accept()));v.addWidget(btn);dialog.exec()
    def preferences(self):
        dlg=QDialog(self);dlg.setWindowTitle('Ajustes de Descarga Fácil');dlg.resize(490,330);v=QVBoxLayout(dlg)
        v.addWidget(label('Preferencias','brand'))
        for key,name in [('capture','Capturar descargas de archivos desde Edge'),('notifications','Avisar al finalizar (en la aplicación)')]:
            cb=QCheckBox(name);cb.setChecked(bool(settings[key]));cb.toggled.connect(lambda checked,k=key:(settings.update({k:checked}),save()));v.addWidget(cb)
        startup=QCheckBox('Iniciar con Windows (minimizado)')
        startup.setEnabled(sys.platform == 'win32')
        if startup.isEnabled():
            try:
                startup.setChecked(windows_startup_enabled())
            except OSError:
                startup.setEnabled(False)
                startup.setToolTip('Windows impidió consultar el inicio automático.')
        def change_startup(enabled):
            try:
                set_windows_startup(enabled)
            except OSError:
                startup.blockSignals(True)
                startup.setChecked(not enabled)
                startup.blockSignals(False)
                QMessageBox.warning(dlg, 'Iniciar con Windows', 'Windows impidió cambiar el inicio automático.')
        startup.toggled.connect(change_startup)
        v.addWidget(startup)
        accelerate=QCheckBox('Acelerar descargas con varias conexiones (si el servidor lo permite)')
        accelerate.setChecked(settings.get('acceleration',True))
        accelerate.toggled.connect(lambda value:(settings.update(acceleration=value),save()))
        v.addWidget(accelerate)
        v.addWidget(label('Conexiones simultáneas por archivo (recomendado: 8)'))
        count=QSpinBox();count.setRange(1,32);count.setValue(settings.get('connections',8))
        count.valueChanged.connect(lambda value:(settings.update(connections=value),save()))
        v.addWidget(count)
        folder=label('Carpeta: '+settings['download_dir'],'muted');folder.setWordWrap(True);v.addWidget(folder)
        choose=QPushButton('Cambiar carpeta de descargas')
        def pick():
            p=QFileDialog.getExistingDirectory(dlg,'Elegir carpeta',settings['download_dir'])
            if p:settings['download_dir']=p;save();folder.setText('Carpeta: '+p)
        choose.clicked.connect(pick);v.addWidget(choose)
        v.addWidget(label('La extensión de Edge consulta los ajustes al detectar descargas.','muted'));dlg.exec()
    def download(self,url,transfer_url=None,video_format=None):
        url=url.strip()
        parsed=urllib.parse.urlparse(url)
        if parsed.scheme not in ('http','https') or not parsed.netloc:
            QMessageBox.warning(self,'Enlace inválido','Ingresá un enlace HTTP o HTTPS válido.');return
        ident=uuid.uuid4().hex
        filename=Path(urllib.parse.unquote(parsed.path)).name or 'descarga.bin'
        filename=safe_filename(filename)
        job=dict(id=ident,url=url,name=filename,size='—',status='En cola',progress=0,speed='—',bps=0,path='')
        if video_format:
            extension = 'm4a' if video_format == 'audio' else 'mp4'
            job.update(name=f'YouTube - {parsed.query[2:]}.{extension}', video_format=video_format)
        self.controls[ident]={'pause':threading.Event(),'cancel':threading.Event()}
        if transfer_url:
            self.controls[ident]['transfer_url']=transfer_url
        self.jobs[ident]=job
        try:
            self.persist_history(force=True)
        except sqlite3.Error:
            self.jobs.pop(ident)
            self.controls.pop(ident)
            raise
        self.refresh()
        self.start_worker(ident)

    def start_worker(self,ident):
        job=self.jobs[ident];control=self.controls[ident]
        def worker():
            try:
                if control['cancel'].is_set():raise Cancelled()
                if control['pause'].is_set():raise Paused()
                if job.get('video_format'):
                    job.update(status='Descargando', progress=0)
                    self.events.put(('job',job.copy()))
                    def report(percent):
                        if percent > job['progress']:
                            job['progress'] = percent
                            self.events.put(('job',job.copy()))
                    dest = youtube.download(job['url'],job['video_format'],Path(settings['download_dir']),
                                            report,control['pause'],control['cancel'])
                    self.complete_download(job,dest,dest.stat().st_size)
                    return
                transfer_url=control.get('transfer_url')
                url=transfer_url or direct_dropbox_url(job['url'])
                if not job['path']:
                    directory=Path(settings['download_dir']);directory.mkdir(parents=True,exist_ok=True)
                    with urllib.request.urlopen(download_request(url),timeout=45) as resp:
                        validate_dropbox_response(url,resp)
                        prefix=resp.read(131072)
                        real_name=response_filename(resp.headers,resp.geturl(),job['name'],prefix)
                    dest=directory/real_name;n=1
                    while dest.exists() or Path(str(dest)+'.part').exists():
                        dest=directory/f'{Path(real_name).stem} ({n}){Path(real_name).suffix}';n+=1
                    job['name']=dest.name;job['path']=str(dest)
                    self.events.put(('job',job.copy()))
                dest=Path(job['path']);last=[0.0]
                segments = ()

                def report_segments(snapshot):
                    nonlocal segments
                    segments = snapshot

                def progress(done,total,start,base):
                    now=time.monotonic()
                    if now-last[0]<.2 and done!=total:return
                    last[0]=now
                    bps=max(0,done-base)/max(.01,now-start)
                    job.update(status='Descargando',progress=min(99,int(done/total*100)) if total else 0,
                               bps=bps,speed=f'{bps/1048576:.1f} MB/s',
                               size=f'{total/1048576:.1f} MB' if total else 'Desconocido', segments=segments)
                    self.events.put(('job',job.copy()))
                total=segmented_download(url,dest,progress,
                    settings.get('connections',8) if settings.get('acceleration',True) else 1,
                    control['pause'],control['cancel'],private_url=bool(transfer_url),
                    report_segments=report_segments)
                job['segments'] = tuple((received, length or received) for received, length in segments)
                self.complete_download(job,dest,total)
            except Paused:
                job.update(status='Pausado',speed='—',bps=0)
                self.events.put(('job',job.copy()))
            except Cancelled:
                self.cleanup_parts(job)
                job.update(status='Cancelado',speed='—',bps=0)
                self.events.put(('job',job.copy()))
            except Exception as e:
                job.update(status='Error',speed='—',bps=0)
                self.events.put(('job',job.copy()))
                self.events.put(('status','Error descargando '+job['name']+': '+str(e)))
        thread=threading.Thread(target=worker,daemon=True)
        if job.get('video_format'):
            control['video_worker']=thread
        thread.start()

    def complete_download(self,job,dest,total):
        job.update(name=dest.name,path=str(dest),status='Completado',progress=100,speed='—',
                   bps=0,size=f'{total/1048576:.1f} MB')
        self.events.put(('job',job.copy()))
        if settings['notifications']:self.events.put(('status','Descarga completada: '+dest.name))
    def check_app_updates(self):
        self.run_update_check('Descarga Fácil', lambda: check_app_release(GITHUB_REPOSITORY, VERSION))

    def check_engine_updates(self):
        self.run_update_check('Motor de YouTube', lambda: (youtube.update_engine(), None))

    def run_update_check(self, title, check):
        if not self.updates.isEnabled():
            return
        self.updates.setEnabled(False)
        self.status.setText(f'Buscando actualizaciones · {title}…')

        def worker():
            try:
                message, asset = check()
            except (TimeoutError, subprocess.TimeoutExpired):
                message = 'La búsqueda superó el tiempo de espera. Volvé a intentar.'
            except subprocess.CalledProcessError as error:
                message = (error.stderr or '').strip() or 'No se pudo verificar la versión del motor.'
            except (OSError, ValueError) as error:
                message = str(error)
            else:
                self.events.put(('update', (title, True, message, asset)))
                return
            self.events.put(('update', (title, False, message, None)))

        threading.Thread(target=worker, daemon=True).start()

    def show_update_result(self, data):
        title, ok, message, asset = data
        if asset and sys.platform == 'win32':
            prompt = (f'{message}\n\n'
                      f'¿Descargar el instalador ({asset.size / 1048576:.0f} MB) y abrirlo? '
                      'Descarga Fácil se cerrará para instalar la actualización.')
            if QMessageBox.question(self, 'Actualización disponible', prompt) == QMessageBox.Yes:
                self.start_update_download(asset)
                return

        self.updates.setEnabled(True)
        self.status.setText('Búsqueda finalizada.' if ok else 'No se pudo completar la búsqueda de actualizaciones.')
        if asset:
            if sys.platform != 'win32':
                QMessageBox.information(self, title, message + '\n\nEl instalador requiere Windows.')
        elif ok:
            QMessageBox.information(self, title, message)
        else:
            QMessageBox.warning(self, title, message)

    def start_update_download(self, asset):
        self.status.setText('Descargando actualización de Descarga Fácil · 0%')

        def worker():
            try:
                installer = download_installer(
                    asset, ROOT / 'updates', lambda percent: self.events.put(('update_progress', percent)))
            except (OSError, ValueError, HTTPException) as error:
                self.events.put(('installer', (None, str(error))))
            else:
                self.events.put(('installer', (installer, None)))

        threading.Thread(target=worker, daemon=True).start()

    def open_update_installer(self, installer, error):
        self.updates.setEnabled(True)
        if installer is not None:
            try:
                os.startfile(str(installer))
            except OSError as launch_error:
                error = str(launch_error)
            else:
                # Close outside flush() so the normal shutdown can drain its queue.
                self.status.setText('Instalador verificado. Cerrando Descarga Fácil…')
                QTimer.singleShot(0, self.close)
                return

        self.status.setText('No se pudo iniciar la actualización.')
        QMessageBox.warning(self, 'Actualización de Descarga Fácil', error)

    def server(self):
        app=self
        class Handler(BaseHTTPRequestHandler):
            def respond(self,data,status=200):
                body=json.dumps(data).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Access-Control-Allow-Origin','*');self.send_header('Access-Control-Allow-Headers','Content-Type, X-Gestor-Token');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
            def do_OPTIONS(self):self.respond({})
            def authorized(self):return self.headers.get('X-Gestor-Token')==TOKEN
            def do_GET(self):
                if not self.authorized():return self.respond({'error':'unauthorized'},403)
                if self.path=='/settings':return self.respond({'capture':settings['capture'],'videos':settings['videos']})
                self.respond({'error':'not found'},404)
            def do_POST(self):
                if not self.authorized():return self.respond({'error':'unauthorized'},403)
                if self.path not in ('/download','/youtube'):return self.respond({'error':'not found'},404)
                video_format = None
                try:
                    length=int(self.headers.get('Content-Length','0'))
                    if length>8192 or length<=0:return self.respond({'error':'invalid size'},413)
                    data=json.loads(self.rfile.read(length))
                    if self.path=='/youtube':
                        video_id = data['video_id']
                        video_format = data['format']
                        if not re.fullmatch(r'[A-Za-z0-9_-]{11}',video_id) or video_format not in youtube.FORMATS:
                            raise ValueError('invalid video')
                        if not youtube.tools_ready():
                            return self.respond({'error':'video tools unavailable'},424)
                        url = f'https://www.youtube.com/watch?v={video_id}'
                    else:
                        url=data['url'].strip()
                    p=urllib.parse.urlparse(url)
                    if p.scheme not in ('http','https') or not p.hostname:raise ValueError('invalid url')
                except (KeyError, TypeError, ValueError, AttributeError):
                    return self.respond({'error':'invalid url'},400)
                transfer_url = None
                if is_dropbox_url(url):
                    # Validate before asking Edge to give up its authenticated download.
                    direct_url = direct_dropbox_url(url)
                    candidates = [direct_url]
                    final_url = data.get('final_url')
                    if isinstance(final_url,str) and final_url != direct_url:
                        try:
                            final = urllib.parse.urlsplit(final_url)
                            if final.scheme=='https' and not final.username and not final.password and is_dropbox_url(final_url):
                                candidates.append(final_url)
                        except ValueError:
                            pass
                    for candidate in candidates:
                        try:
                            with urllib.request.urlopen(download_request(candidate),timeout=8) as response:
                                validate_dropbox_response(candidate,response)
                        except (OSError,ValueError):
                            continue
                        if candidate != direct_url:
                            transfer_url = candidate
                        break
                    else:
                        return self.respond({'error':'dropbox_unavailable'},422)
                result = Future()
                app.events.put(('download', (url, transfer_url, video_format, result)))
                try:
                    try:
                        result.result(timeout=5)
                    except TimeoutError:
                        if result.cancel():
                            return self.respond({'error':'app busy'},503)
                        result.result()
                except Exception:
                    return self.respond({'error':'could not add download'},500)
                self.respond({'ok':True})
            def log_message(self,*args):pass
        try:ThreadingHTTPServer(('127.0.0.1',8765),Handler).serve_forever()
        except OSError:self.events.put(('status','Puerto 8765 ocupado: cerrá la versión anterior de Gestor Personal.'))

if __name__=='__main__':
    start_minimized = '--startup' in sys.argv[1:]
    app=QApplication(sys.argv);app.setStyleSheet(STYLE);win=Main()
    if start_minimized:
        win.showMinimized()
    else:
        win.show()
    sys.exit(app.exec())
