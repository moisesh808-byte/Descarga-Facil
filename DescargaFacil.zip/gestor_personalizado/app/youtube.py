"""Manual video downloads using the Windows tools installed alongside the app."""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

from segmented import check


FORMATS = {
    'mp4-1080': 1080,
    'mp4-720': 720,
    'audio': None,
}
TOOLS = (Path(sys.executable).parent if getattr(sys, 'frozen', False)
         else Path(__file__).resolve().parents[1]) / 'tools'
USER_ENGINE = Path(os.getenv('LOCALAPPDATA', str(Path.home()))) / 'DescargaFacil' / 'motor' / 'yt-dlp.exe'
CREATE_NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0)


def engine_path():
    return USER_ENGINE if USER_ENGINE.is_file() else TOOLS / 'yt-dlp.exe'


def update_engine():
    current = engine_path()
    if not current.is_file():
        raise OSError('Volvé a instalar Descarga Fácil para agregar el motor de YouTube.')
    USER_ENGINE.parent.mkdir(parents=True, exist_ok=True)
    options = dict(capture_output=True, text=True, encoding='utf-8', errors='replace',
                   creationflags=CREATE_NO_WINDOW, stdin=subprocess.DEVNULL)
    # Update a copy so an interrupted update leaves the working engine intact.
    with TemporaryDirectory(dir=USER_ENGINE.parent, ignore_cleanup_errors=True) as temporary:
        staged = Path(temporary) / USER_ENGINE.name
        shutil.copyfile(current, staged)
        command = [str(staged), '--ignore-config']
        before = subprocess.run([*command, '--version'], check=True, timeout=30, **options).stdout.strip()
        result = subprocess.run([*command, '--socket-timeout', '30', '-U'], timeout=180, **options)
        details = (result.stdout + '\n' + result.stderr).strip()
        if result.returncode or 'ERROR:' in details:
            raise OSError(details or 'No se pudo actualizar el motor de YouTube.')
        after = subprocess.run([*command, '--version'], check=True, timeout=30, **options).stdout.strip()
        if not before or not after:
            raise OSError('No se pudo verificar la versión del motor de YouTube.')
        if before == after:
            return f'El motor de YouTube está al día ({after}).'
        try:
            staged.replace(USER_ENGINE)
        except PermissionError as error:
            raise OSError('Windows impidió cambiar el motor. Si hay una descarga de YouTube activa, esperá a que termine y volvé a intentar.') from error
        return f'Motor de YouTube actualizado de {before} a {after}.'


def tools_ready():
    return engine_path().is_file() and all((TOOLS / name).is_file() for name in
                                           ('ffmpeg.exe', 'ffprobe.exe', 'deno.exe'))


def stop_process(process):
    if process.poll() is not None:
        return
    if sys.platform == 'win32':
        taskkill = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32' / 'taskkill.exe'
        try:
            subprocess.run([str(taskkill), '/PID', str(process.pid), '/T', '/F'],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           creationflags=CREATE_NO_WINDOW, timeout=2)
        except (OSError, subprocess.TimeoutExpired):
            pass
    if process.poll() is None:
        process.kill()
    process.wait()


def download(url, video_format, directory, report, pause, cancel):
    if not tools_ready():
        raise OSError('Volvé a instalar Descarga Fácil para agregar los componentes de YouTube.')
    directory.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix='.df-video-', dir=directory) as temporary:
        staging = Path(temporary).resolve()
        options = [
            str(engine_path()), '--ignore-config', '--no-playlist',
            '--js-runtimes', f'deno:{TOOLS / "deno.exe"}',
            '--ffmpeg-location', str(TOOLS), '--windows-filenames', '--socket-timeout', '15',
            '--encoding', 'utf-8', '--newline', '--progress',
            '--progress-template', 'download:DF_PROGRESS:%(progress._percent_str)s',
            '--print', 'after_move:DF_FILE:%(filepath)j',
            '--output', str(staging / '%(title).140B [%(id)s].%(ext)s'),
        ]
        height = FORMATS[video_format]
        if height is None:
            options += ['-f', 'bestaudio/best', '-x', '--audio-format', 'm4a']
        else:
            video = f'[ext=mp4][vcodec^=avc1][height<={height}]'
            options += ['-f', f'bv{video}+ba[ext=m4a][acodec^=mp4a]/b{video}[acodec^=mp4a]',
                        '--merge-output-format', 'mp4']
        log = staging / 'download.log'
        final_path = None
        last_error = ''
        with log.open('wb') as writer, log.open(encoding='utf-8', errors='replace') as reader:
            process = subprocess.Popen([*options, '--', url], stdin=subprocess.DEVNULL,
                                       stdout=writer, stderr=subprocess.STDOUT,
                                       creationflags=CREATE_NO_WINDOW)
            pending = ''
            try:
                while True:
                    check(pause,cancel)
                    finished = process.poll() is not None
                    lines = (pending + reader.read()).split('\n')
                    pending = '' if finished else lines.pop()
                    for line in lines:
                        if line.startswith('DF_PROGRESS:'):
                            value = line.removeprefix('DF_PROGRESS:').strip().rstrip('%')
                            try:
                                report(max(0, min(99, int(float(value)))))
                            except (ValueError, OverflowError):
                                pass
                        elif line.startswith('DF_FILE:'):
                            final_path = Path(json.loads(line.removeprefix('DF_FILE:'))).resolve()
                        elif line.startswith('ERROR:'):
                            last_error = line.removeprefix('ERROR:').strip()
                    if finished:
                        break
                    pause.wait(0.2)
            finally:
                stop_process(process)
        if process.returncode or final_path is None:
            raise OSError(last_error or 'No se pudo obtener el formato seleccionado.')
        extension = '.m4a' if height is None else '.mp4'
        if final_path.parent != staging or final_path.suffix.lower() != extension or not final_path.is_file():
            raise OSError('El archivo recibido no coincide con el formato elegido.')
        check(pause,cancel)
        target = directory / final_path.name
        counter = 1
        while True:
            try:
                with target.open('xb'):
                    pass
                break
            except FileExistsError:
                target = directory / f'{final_path.stem} ({counter}){extension}'
                counter += 1
        try:
            final_path.replace(target)
        except OSError:
            target.unlink(missing_ok=True)
            raise
        return target
