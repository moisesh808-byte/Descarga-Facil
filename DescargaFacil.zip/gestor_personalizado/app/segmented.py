"""Resumable HTTP downloader with validated byte ranges and cooperative pause/cancel."""
import hashlib, json, os, re, time, threading, urllib.parse, urllib.request
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

HEADERS={'User-Agent':'Mozilla/5.0 DescargaFacil/0.6.0','Accept-Encoding':'identity'}
BLOCK=256*1024

class Paused(Exception): pass
class Cancelled(Exception): pass
class DropboxPageError(OSError): pass

def is_dropbox_url(url):
    host = (urllib.parse.urlsplit(url).hostname or '').rstrip('.').lower()
    return any(host == domain or host.endswith('.' + domain)
               for domain in ('dropbox.com', 'dropboxusercontent.com'))

def direct_dropbox_url(url):
    parts = urllib.parse.urlsplit(url)
    if parts.hostname not in ('www.dropbox.com', 'dropbox.com'):
        return url
    if not parts.path.startswith(('/s/', '/scl/fi/', '/sh/', '/scl/fo/')):
        return url
    query = [field for field in parts.query.split('&')
             if field and field.split('=', 1)[0] not in ('dl', 'raw')]
    query.append('dl=1')
    return parts._replace(query='&'.join(query)).geturl()

def validate_dropbox_response(url, response):
    final_url = response.geturl()
    if not (is_dropbox_url(url) or is_dropbox_url(final_url)):
        return
    path = urllib.parse.urlsplit(final_url).path.rstrip('/').lower()
    disposition = response.headers.get('Content-Disposition', '').split(';', 1)[0].strip().lower()
    html = response.headers.get_content_type() in ('text/html', 'application/xhtml+xml')
    if path == '/login' or (html and disposition != 'attachment'):
        raise DropboxPageError('Dropbox devolvió una página en vez del archivo. Abrí el enlace y descargalo con Edge.')

def check(pause, cancel):
    if cancel is not None and cancel.is_set(): raise Cancelled()
    if pause is not None and pause.is_set(): raise Paused()

def request(url, extra=None):
    return urllib.request.Request(url,headers={**HEADERS,**(extra or {})})

def download(url,dest,progress,connections=8,pause=None,cancel=None,*,private_url=False,report_segments=None):
    """Resume only if server validates the same resource; partial data stays on pause."""
    dest=Path(dest);part=Path(str(dest)+'.part');meta=Path(str(dest)+'.part.json')
    check(pause,cancel)
    with urllib.request.urlopen(request(url,{'Range':'bytes=0-0'}),timeout=45) as probe:
        validate_dropbox_response(url,probe)
        match=re.fullmatch(r'bytes 0-0/(\d+)',probe.headers.get('Content-Range','').strip())
        total=int(match.group(1)) if probe.status==206 and match else 0
        ranged=bool(total and len(probe.read(2))==1 and probe.headers.get('Content-Encoding','identity').lower()=='identity')
        etag=probe.headers.get('ETag','');modified=probe.headers.get('Last-Modified','')
        final_url=probe.geturl()
    n=min(max(1,int(connections)),max(1,total//(1024*1024))) if ranged and total>=2*1024*1024 else 1
    if not ranged:n=1
    # Single-stream mode also resumes if the server supports byte ranges.
    spans=[(i*total//n,(i+1)*total//n-1) for i in range(n)] if ranged else []
    signature={'url':url,'final_url':final_url,'total':total,'etag':etag,'modified':modified,'n':n,'spans':spans}
    if private_url:
        # Keep temporary browser URLs out of the partial download metadata.
        signature['url']=hashlib.sha256(url.encode()).hexdigest()
        signature['final_url']=hashlib.sha256(final_url.encode()).hexdigest()
        signature['spans']=[list(span) for span in spans]
    existing=None
    try: existing=json.loads(meta.read_text(encoding='utf-8'))
    except (OSError,ValueError): pass
    reusable=(existing is not None and all(existing.get(k)==v for k,v in signature.items()) and part.exists() and (not total or part.stat().st_size==total))
    if not reusable:
        part.unlink(missing_ok=True);meta.unlink(missing_ok=True)
    if ranged:
        done=list(existing.get('done',[])) if reusable else [0]*n
        if len(done)!=n or any(not isinstance(d,int) or d<0 or d>e-s+1 for d,(s,e) in zip(done,spans)):
            done=[0]*n;reusable=False
        if not reusable:
            with open(part,'wb') as f:f.truncate(total)
        signature['done']=done
        meta.write_text(json.dumps(signature),encoding='utf-8')
        lock=threading.Lock();start=time.monotonic();base=sum(done)
        def publish_progress():
            if report_segments is not None:
                report_segments(tuple((received, end - first + 1)
                                      for received, (first, end) in zip(done, spans)))
            progress(sum(done),total,start,base)
        publish_progress()

        def persist():
            with lock:meta.write_text(json.dumps(signature),encoding='utf-8')
        def fetch(i,s,e):
            if done[i]==e-s+1:return
            pos=s+done[i];extra={'Range':f'bytes={pos}-{e}'}
            if etag and not etag.startswith('W/'):extra['If-Range']=etag
            elif modified:extra['If-Range']=modified
            check(pause,cancel)
            with urllib.request.urlopen(request(final_url,extra),timeout=60) as resp:
                validate_dropbox_response(url,resp)
                if resp.status!=206 or resp.headers.get('Content-Range','').strip()!=f'bytes {pos}-{e}/{total}':
                    raise IOError('El servidor cambió el archivo o no respeta los rangos; no se puede reanudar de forma segura.')
                if resp.headers.get('Content-Encoding','identity').lower()!='identity':raise IOError('Segmento comprimido inesperadamente')
                with open(part,'r+b',buffering=0) as f:
                    while pos<=e:
                        check(pause,cancel)
                        chunk=resp.read(min(BLOCK,e-pos+1))
                        if not chunk:raise IOError('Segmento incompleto')
                        f.seek(pos);f.write(chunk);pos+=len(chunk)
                        with lock:
                            done[i]+=len(chunk)
                            publish_progress()
                        # Persist after each chunk so interruption never claims unwritten data.
                        persist()
        try:
            with ThreadPoolExecutor(max_workers=n) as pool:
                futures=[pool.submit(fetch,i,s,e) for i,(s,e) in enumerate(spans)]
                errors=[]
                for future in as_completed(futures):
                    try:future.result()
                    except Exception as exc:
                        errors.append(exc)
                if errors:raise errors[0]
            check(pause,cancel)
            if any(done[i]!=e-s+1 for i,(s,e) in enumerate(spans)):raise IOError('Segmentos incompletos')
            os.replace(part,dest);meta.unlink(missing_ok=True)
            return total
        except Cancelled:
            part.unlink(missing_ok=True);meta.unlink(missing_ok=True);raise
    # Unknown size / no range: cannot resume; pause discards partial to avoid corruption.
    part.unlink(missing_ok=True);meta.unlink(missing_ok=True)
    try:
        with urllib.request.urlopen(request(url),timeout=45) as resp:
            validate_dropbox_response(url,resp)
            expected=int(resp.headers.get('Content-Length','0') or 0)
            count=0;start=time.monotonic()
            if report_segments is not None:
                report_segments(((0, expected),))
            progress(0,expected,start,0)
            with open(part,'wb') as f:
                while True:
                    check(pause,cancel)
                    chunk=resp.read(BLOCK)
                    if not chunk:break
                    f.write(chunk);count+=len(chunk)
                    if report_segments is not None:
                        report_segments(((count, expected),))
                    progress(count,expected,start,0)
            check(pause,cancel)
            if expected and count!=expected:raise IOError('Archivo incompleto')
        os.replace(part,dest);return count
    except (Paused,Cancelled):
        part.unlink(missing_ok=True);raise
