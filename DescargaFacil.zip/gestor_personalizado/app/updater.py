"""Check and download the Windows installer from the project's GitHub release."""
import hashlib
import json
import os
import re
import tempfile
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote, urlsplit


@dataclass(frozen=True)
class UpdateAsset:
    url: str
    size: int
    sha256: str


def check_app_release(repository, version):
    request = urllib.request.Request(
        f'https://api.github.com/repos/{repository}/releases/latest',
        headers={'User-Agent': f'DescargaFacil/{version}', 'Accept': 'application/vnd.github+json',
                 'Cache-Control': 'no-cache'},
    )
    try:
        with urllib.request.urlopen(request, timeout=12) as response:
            release = json.load(response)
    except HTTPError as error:
        if error.code == 404:
            return f'Versión instalada: {version}\n\nAún no hay una versión pública publicada.', None
        raise

    tag = release.get('tag_name') if isinstance(release, dict) else None
    match = re.fullmatch(r'[vV]?([0-9]+\.[0-9]+\.[0-9]+)', tag or '') if isinstance(tag, str) else None
    if match is None:
        raise ValueError('La versión publicada debe tener una etiqueta como v0.6.6.')
    latest_version = match[1]
    summary = f'Versión instalada: {version}\nÚltima versión publicada: {tag}'
    if tuple(map(int, latest_version.split('.'))) <= tuple(map(int, version.split('.'))):
        return summary + '\n\nYa tenés la versión publicada o una más reciente.', None

    name = f'DescargaFacil-Setup-v{latest_version}.exe'
    url = f'https://github.com/{repository}/releases/download/{quote(tag, safe="")}/{name}'
    for asset in release.get('assets', []):
        if asset.get('name') != name or asset.get('state') != 'uploaded':
            continue
        raw_digest = asset.get('digest')
        digest = re.fullmatch(r'sha256:([a-f0-9]{64})', raw_digest) if isinstance(raw_digest, str) else None
        size = asset.get('size')
        if asset.get('browser_download_url') == url and type(size) is int and size > 0 and digest:
            return summary, UpdateAsset(url, size, digest[1])
    raise ValueError(f'El instalador verificable de la versión {tag} todavía no está disponible.')


def download_installer(asset, directory, report):
    directory.mkdir(parents=True, exist_ok=True)
    installer = directory / 'DescargaFacil-Update.exe'
    temporary = None
    try:
        request = urllib.request.Request(asset.url, headers={'User-Agent': 'DescargaFacil'})
        with urllib.request.urlopen(request, timeout=30) as response:
            if urlsplit(response.geturl()).scheme != 'https':
                raise ValueError('La descarga del instalador requiere HTTPS.')
            with tempfile.NamedTemporaryFile(dir=directory, suffix='.part', delete=False) as output:
                temporary = Path(output.name)
                digest = hashlib.sha256()
                received = 0
                previous = 0
                while chunk := response.read(1024 * 1024):
                    received += len(chunk)
                    if received > asset.size:
                        raise ValueError('El tamaño del instalador no coincide con la publicación.')
                    output.write(chunk)
                    digest.update(chunk)
                    percent = min(99, received * 100 // asset.size)
                    if percent != previous:
                        report(percent)
                        previous = percent
        if received != asset.size or digest.hexdigest() != asset.sha256:
            raise ValueError('La descarga quedó incompleta o el instalador no pasó la verificación SHA-256.')
        os.replace(temporary, installer)
        return installer
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def launch_installer_after_exit(installer, parent_pid):
    """Launch a detached Windows helper which waits for the running app to exit.

    Never start Inno Setup while PyInstaller's onefile executable is still alive.
    """
    import subprocess
    import sys
    if sys.platform != 'win32':
        raise OSError('La instalación automática requiere Windows.')
    installer = Path(installer).resolve()
    if not installer.is_file() or installer.suffix.lower() != '.exe':
        raise FileNotFoundError('No se encontró el instalador descargado.')
    # Use an independent PowerShell process and write a diagnostic log.
    # This helper survives app shutdown and reports installer-launch failures.
    log = installer.parent / 'actualizador.log'
    script = (
        '$ErrorActionPreference = "Stop"; '
        f'$pidToWait = {int(parent_pid)}; '
        '$log = ' + "'" + str(log).replace("'", "''") + "'; " +
        '$installer = ' + "'" + str(installer).replace("'", "''") + "'; " +
        'try { '
        '"Esperando cierre del programa" | Out-File -FilePath $log -Encoding utf8; '
        'try { Wait-Process -Id $pidToWait -Timeout 120 -ErrorAction Stop } '
        'catch { if (Get-Process -Id $pidToWait -ErrorAction SilentlyContinue) { throw "La aplicación no se cerró en 120 segundos" } }; '
        'Start-Sleep -Seconds 2; '
        'if (-not (Test-Path -LiteralPath $installer)) { throw "Instalador no encontrado" }; '
        'Start-Process -FilePath $installer -ErrorAction Stop; '
        '"Instalador iniciado" | Out-File -FilePath $log -Append -Encoding utf8 '
        '} catch { ($_ | Out-String) | Out-File -FilePath $log -Append -Encoding utf8; exit 1 }'
    )
    flags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
    subprocess.Popen(
        ['powershell.exe', '-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden',
         '-Command', script],
        creationflags=flags, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL, close_fds=True,
    )
