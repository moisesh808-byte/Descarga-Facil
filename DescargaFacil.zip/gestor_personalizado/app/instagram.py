"""Public Instagram photo/carousel downloads through gallery-dl."""
import os
import re
import subprocess
import sys
import time
import uuid
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from segmented import Paused, Cancelled

CREATE_NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
TOOLS = (Path(sys.executable).parent if getattr(sys, 'frozen', False)
         else Path(__file__).resolve().parents[1]) / 'tools'

def is_instagram_post(url):
    parsed=urlparse(url)
    host=(parsed.hostname or '').lower()
    return (parsed.scheme in ('http','https') and host in ('instagram.com','www.instagram.com')
            and bool(re.fullmatch(r'/(p|reel|tv)/[A-Za-z0-9_-]+/?',parsed.path)))

def download(url, directory, pause, cancel):
    if not is_instagram_post(url):
        raise ValueError('Enlace de Instagram no compatible.')
    engine=TOOLS/'gallery-dl.exe'
    if not engine.is_file():
        raise OSError('Falta gallery-dl.exe. Instalá la versión completa de Descarga Fácil.')
    directory.mkdir(parents=True,exist_ok=True)
    destination=directory / ('Instagram-' + uuid.uuid4().hex[:10])
    destination.mkdir()
    # Download exactly the selected image, not an entire carousel.
    # gallery-dl --range selects an item before any image filtering.
    query=parse_qs(urlparse(url).query)
    try:
        index=max(1,int(query.get('img_index',['1'])[0]))
    except (ValueError,TypeError):
        index=1
    command=[str(engine),'--ignore-config','--no-mtime',
             '--range',f'{index}-{index}',
             '-D',str(destination),'-o','directory=[]',url]
    proc=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT,creationflags=CREATE_NO_WINDOW)
    try:
        # Communicate in a worker thread to avoid a full stdout pipe deadlock.
        import threading
        output_holder={}
        reader=threading.Thread(target=lambda:output_holder.update(output=proc.communicate()[0]),daemon=True)
        reader.start()
        while reader.is_alive():
            if cancel.is_set() or pause.is_set():
                proc.kill();reader.join(timeout=5)
                if cancel.is_set():raise Cancelled()
                raise Paused()
            reader.join(.15)
        output=output_holder.get('output',b'').decode('utf-8','replace')[-3000:]
        files=sorted(p for p in destination.rglob('*') if p.is_file() and p.suffix.lower() in
                     ('.jpg','.jpeg','.png','.webp','.gif'))
        if proc.returncode or not files:
            detail=output[-900:].strip() or 'Instagram no devolvió una fotografía.'
            raise OSError('Instagram: '+detail)
        # The requested item might be a video; don't silently save all carousel items.
        return destination,files

    finally:
        if proc.poll() is None:proc.kill()
        if proc.stdout:proc.stdout.close()
