#define AppName "Descarga Fácil"
#define AppVersion "0.6.9"
[Setup]
AppId={{A36C3B70-8C45-4C1F-8F8A-2A934C4B70E5}
AppName={#AppName}
AppVersion={#AppVersion}
DefaultDirName={autopf}\Descarga Facil
DefaultGroupName={#AppName}
OutputDir=instalador
OutputBaseFilename=DescargaFacil-Setup-v{#AppVersion}
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
WizardStyle=modern
UninstallDisplayIcon={app}\DescargaFacil.exe
SetupIconFile=app\icon.ico
[Files]
Source: "dist\DescargaFacil.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "tools\gallery-dl.exe"; DestDir: "{app}\tools"; Flags: ignoreversion
Source: "tools\yt-dlp.exe"; DestDir: "{app}\tools"; Flags: ignoreversion
Source: "tools\ffmpeg.exe"; DestDir: "{app}\tools"; Flags: ignoreversion
Source: "tools\ffprobe.exe"; DestDir: "{app}\tools"; Flags: ignoreversion
Source: "tools\deno.exe"; DestDir: "{app}\tools"; Flags: ignoreversion
[Icons]
Name: "{group}\Descarga Fácil"; Filename: "{app}\DescargaFacil.exe"
Name: "{autodesktop}\Descarga Fácil"; Filename: "{app}\DescargaFacil.exe"; Tasks: desktopicon
[Tasks]
Name: desktopicon; Description: "Crear acceso directo en el escritorio"; GroupDescription: "Accesos directos:"; Flags: checkedonce
Name: startup; Description: "Iniciar Descarga Fácil con Windows en el área de notificación"
[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "DescargaFacil"; ValueData: """{app}\DescargaFacil.exe"" --startup"; Flags: uninsdeletevalue; Tasks: startup
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: none; ValueName: "DescargaFacil"; Flags: deletevalue dontcreatekey uninsdeletevalue; Tasks: not startup
[Run]
Filename: "{app}\DescargaFacil.exe"; Description: "Abrir Descarga Fácil"; Flags: nowait postinstall skipifsilent
