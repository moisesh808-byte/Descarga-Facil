chrome.storage.local.get('token',x=>document.getElementById('token').value=x.token||'');
document.getElementById('save').onclick=()=>chrome.storage.local.set({token:document.getElementById('token').value.trim()},()=>document.getElementById('status').textContent='Guardado');
