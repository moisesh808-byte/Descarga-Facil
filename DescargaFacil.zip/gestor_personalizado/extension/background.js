const BASE='http://127.0.0.1:8765';
const pending=new Map();
async function token(){return (await chrome.storage.local.get('token')).token||'';}
async function request(path,opts={}){
  const t=await token();
  if(!t)throw Error('Configurá el token en las opciones de la extensión.');
  let response;
  try{
    response=await fetch(BASE+path,{...opts,headers:{'X-Gestor-Token':t,'Content-Type':'application/json'}});
  }catch{
    throw Error('No hay conexión con Descarga Fácil. Abrí la app y volvé a intentar.');
  }
  if(response.status===403)throw Error('El token no coincide. Copiá el de la app en las opciones de la extensión.');
  if(response.status===422){
    const detail=await response.json();
    if(detail.error==='dropbox_unavailable')throw Error('Descarga Fácil no pudo obtener el archivo de Dropbox.');
  }
  if(response.status===503)throw Error('Descarga Fácil está ocupada. Volvé a intentar.');
  if(path==='/youtube' && response.status===404)throw Error('Instalá Descarga Fácil v0.6.0 o posterior.');
  if(path==='/youtube' && response.status===424)throw Error('Volvé a instalar la app para agregar los componentes de YouTube.');
  if(!response.ok)throw Error('Descarga Fácil rechazó la solicitud (HTTP '+response.status+').');
  return response.json();
}
function notice(message){chrome.notifications.create({type:'basic',iconUrl:'icon.png',title:'Descarga Fácil',message});}
function isProtectedDownload(value){
  try { const host=new URL(value).hostname.toLowerCase();
    return ['dropbox.com','dropboxusercontent.com','pixabay.com','cdn.pixabay.com'].some(d=>host===d||host.endsWith('.'+d));
  }catch{return false;}
}
function isDropboxUrl(value){
  if(!value)return false;
  const url=new URL(value);
  return url.protocol==='https:' && !url.username && !url.password &&
    ['dropbox.com','dropboxusercontent.com'].some(domain=>
      url.hostname===domain || url.hostname.endsWith('.'+domain));
}
chrome.runtime.onInstalled.addListener(()=>{chrome.contextMenus.create({id:'send',title:'Descargar enlace con Descarga Fácil',contexts:['link']});chrome.runtime.openOptionsPage();});
chrome.contextMenus.onClicked.addListener(async info=>{if(info.menuItemId==='send'&&info.linkUrl){try{await request('/download',{method:'POST',body:JSON.stringify({url:info.linkUrl})});}catch(e){notice(e.message+' Abrí el enlace para descargar con Edge.');}}});
// Intercepta solo descargas HTTP(S) normales. Si falla la extensión, Edge continúa.
chrome.downloads.onCreated.addListener(async item=>{
  if(!/^https?:\/\//i.test(item.url) || item.byExtensionId===chrome.runtime.id)return;
  try{
    const s=await request('/settings');if(!s.capture)return;
    // Dropbox entrega URLs CDN temporales para descargas iniciadas desde su web.
    // Reenviarlas sin la sesión de Edge provoca 403, incluso si el sondeo inicial pasa.
    // Mantener la descarga original en Edge; los vínculos compartidos siguen funcionando
    // mediante 'Agregar URL' en la aplicación.
    if(isProtectedDownload(item.url)){
      notice('Este sitio requiere una descarga autenticada. Edge continuará normalmente para evitar el error 403.');
      return;
    }
    // No interrumpir descargas ya terminadas.
    const current=await chrome.downloads.search({id:item.id});if(!current.length||current[0].state!=='in_progress')return;
    try{await chrome.downloads.pause(item.id);}catch(e){return;}
    const nid='df-choice-'+item.id;
    pending.set(nid,{id:item.id,url:item.url});
    await chrome.storage.session.set({[nid]:{id:item.id,url:item.url}});
    await chrome.notifications.create(nid,{type:'basic',iconUrl:'icon.png',title:'Descarga Fácil — ¿Dónde descargar?',message:(item.filename?.split(/[\\/]/).pop()||item.url).slice(0,180),buttons:[{title:'Descarga Fácil'},{title:'Normal con Edge'}],priority:2,requireInteraction:true});
    // Respaldo: si no se responde, Edge reanuda tras 60 segundos.
    await chrome.alarms.create(nid,{delayInMinutes:1});
  }catch(e){try{await chrome.downloads.resume(item.id);}catch(_){} }
});
async function resolveChoice(nid,choice){
  const saved=pending.get(nid)||(await chrome.storage.session.get(nid))[nid];if(!saved)return;
  pending.delete(nid);await chrome.storage.session.remove(nid);await chrome.alarms.clear(nid);await chrome.notifications.clear(nid);
  if(choice==='app'){
    try{
      const data={url:saved.url};
      if(isDropboxUrl(saved.url)){
        const [current]=await chrome.downloads.search({id:saved.id}).catch(()=>[]);
        if(current?.finalUrl && current.finalUrl!==saved.url && isDropboxUrl(current.finalUrl)){
          data.final_url=current.finalUrl;
        }
      }
      await request('/download',{method:'POST',body:JSON.stringify(data)});
    }catch(e){
      notice(e.message+' La descarga continuará en Edge.');
      try{await chrome.downloads.resume(saved.id);}catch(_){}
      return;
    }
    try{await chrome.downloads.cancel(saved.id);await chrome.downloads.erase({id:saved.id});}catch(_){}
  }else{try{await chrome.downloads.resume(saved.id);}catch(_){} }
}
chrome.notifications.onButtonClicked.addListener((id,index)=>{if(id.startsWith('df-choice-'))resolveChoice(id,index===0?'app':'browser');});
chrome.notifications.onClosed.addListener(id=>{if(id.startsWith('df-choice-'))resolveChoice(id,'browser');});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name.startsWith('df-choice-'))resolveChoice(alarm.name,'browser');});
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message?.type!=='df-youtube' || sender.origin!=='https://www.youtube.com')return;
  if(!/^[\w-]{11}$/.test(message.videoId || '') || !['mp4-1080','mp4-720','audio'].includes(message.format)){
    reply({error:'Video o formato inválido.'});
    return;
  }
  const body=JSON.stringify({video_id:message.videoId,format:message.format});
  request('/youtube',{method:'POST',body}).then(
    ()=>reply({ok:true}),
    error=>reply({error:error.message})
  );
  return true;
});
