(() => {
  const formats = [
    ['mp4-1080', 'MP4 hasta 1080p'],
    ['mp4-720', 'MP4 hasta 720p'],
    ['audio', 'Solo audio (M4A)'],
  ];
  let widget;
  let videoId;

  function placeButton(){
    const id = new URL(location.href).searchParams.get('v');
    const player = location.pathname === '/watch' && /^[\w-]{11}$/.test(id || '')
      ? document.querySelector('#movie_player') : null;
    if(!player){
      widget?.remove();
      return;
    }
    if(widget?.parentNode === player && videoId === id)return;
    widget?.remove();
    videoId = id;
    widget = document.createElement('div');
    widget.className = 'df-youtube-widget';
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = '⬇ Descargar video';
    button.setAttribute('aria-expanded','false');
    const menu = document.createElement('div');
    menu.hidden = true;
    const status = document.createElement('div');
    status.setAttribute('role','status');
    for(const [format, label] of formats){
      const choice = document.createElement('button');
      choice.type = 'button';
      choice.textContent = label;
      choice.addEventListener('click', async event=>{
        event.stopPropagation();
        if(!event.isTrusted || choice.disabled)return;
        for(const option of menu.children)option.disabled = true;
        status.textContent = 'Enviando a Descarga Fácil…';
        try{
          const result = await chrome.runtime.sendMessage({type:'df-youtube', videoId:id, format});
          status.textContent = result?.ok ? 'Agregado a Descarga Fácil.' :
            (result?.error || 'No se pudo agregar la descarga.');
        }catch{
          status.textContent = 'Recargá YouTube después de actualizar la extensión.';
        }finally{
          for(const option of menu.children)option.disabled = false;
        }
      });
      menu.append(choice);
    }
    button.addEventListener('click', event=>{
      event.stopPropagation();
      menu.hidden = !menu.hidden;
      button.setAttribute('aria-expanded', String(!menu.hidden));
      if(!menu.hidden)status.textContent = '';
    });
    widget.append(button,menu,status);
    player.append(widget);
  }

  let scheduled = false;
  function schedulePlacement(){
    if(scheduled)return;
    scheduled = true;
    requestAnimationFrame(()=>{
      scheduled = false;
      placeButton();
    });
  }

  document.addEventListener('yt-navigate-finish',schedulePlacement);
  new MutationObserver(schedulePlacement).observe(document.documentElement,{childList:true,subtree:true});
  placeButton();
})();
