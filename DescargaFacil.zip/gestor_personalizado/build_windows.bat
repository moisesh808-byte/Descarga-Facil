@echo off
setlocal
cd /d "%~dp0"
py prepare_video_tools.py
if errorlevel 1 (echo ERROR preparando componentes para YouTube & pause & exit /b 1)
py -m pip install --upgrade pyinstaller PySide6
if errorlevel 1 (echo ERROR instalando PyInstaller & pause & exit /b 1)
py -m PyInstaller --noconfirm --clean --onefile --windowed --icon "app\icon.ico" --add-data "app\icon.ico;." --name "DescargaFacil" app\main.py
if errorlevel 1 (echo ERROR creando ejecutable & pause & exit /b 1)
echo Ejecutable listo en dist\DescargaFacil.exe
where ISCC.exe >nul 2>&1
if not errorlevel 1 (ISCC.exe installer.iss & goto done)
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" installer.iss & goto done)
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" ("%ProgramFiles%\Inno Setup 6\ISCC.exe" installer.iss & goto done)
echo No se encontro Inno Setup automaticamente.
echo Abri installer.iss con Inno Setup y presiona Compile.
:done
echo Revisa la carpeta instalador para el Setup.
pause
