"""Prepare the official Windows x64 binaries used by the local installer."""
import hashlib
import re
import shutil
import urllib.request
import zipfile
from pathlib import Path
from tempfile import TemporaryDirectory


TOOLS = Path(__file__).resolve().parent / 'tools'
YT_DLP = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/'
DENO = 'https://github.com/denoland/deno/releases/latest/download/'
FFMPEG = 'https://www.gyan.dev/ffmpeg/builds/'


def fetch(url, target):
    print(f'Descargando {target.name}...', flush=True)
    with urllib.request.urlopen(url, timeout=60) as response, target.open('wb') as output:
        shutil.copyfileobj(response, output)


def verify(file, checksum_url, name_in_manifest=None):
    with urllib.request.urlopen(checksum_url, timeout=30) as response:
        manifest = response.read(65536).decode('utf-8')
    if name_in_manifest:
        pattern = rf'(?mi)^([0-9a-f]{{64}})[ \t]+\*?{re.escape(name_in_manifest)}[ \t]*$'
        match = re.search(pattern, manifest)
    else:
        match = re.match(r'(?i)([0-9a-f]{64})(?:\s|$)', manifest.strip())
        if not match:
            # Deno's Windows releases use the Get-FileHash output format.
            match = re.search(r'(?mi)^Hash[ \t]*:[ \t]*([0-9a-f]{64})[ \t]*\r?$', manifest)
    digest = hashlib.sha256()
    with file.open('rb') as downloaded:
        for block in iter(lambda: downloaded.read(1024 * 1024), b''):
            digest.update(block)
    if not match or match.group(1).lower() != digest.hexdigest():
        raise ValueError(f'La suma SHA-256 de {file.name} no coincide.')


def unpack(archive, directory, *names):
    with zipfile.ZipFile(archive) as source:
        for name in names:
            member, = [entry for entry in source.namelist() if entry.rsplit('/', 1)[-1] == name]
            with source.open(member) as binary, (directory / name).open('wb') as output:
                shutil.copyfileobj(binary, output)


def main():
    TOOLS.mkdir(exist_ok=True)
    with TemporaryDirectory(dir=TOOLS) as temporary:
        work = Path(temporary)
        if not (TOOLS / 'yt-dlp.exe').is_file():
            file = work / 'yt-dlp.exe'
            fetch(YT_DLP + file.name, file)
            verify(file, YT_DLP + 'SHA2-256SUMS', file.name)
            file.replace(TOOLS / file.name)
        if not (TOOLS / 'deno.exe').is_file():
            archive = work / 'deno-x86_64-pc-windows-msvc.zip'
            fetch(DENO + archive.name, archive)
            verify(archive, DENO + archive.name + '.sha256sum')
            unpack(archive, work, 'deno.exe')
            (work / 'deno.exe').replace(TOOLS / 'deno.exe')
        binaries = ('ffmpeg.exe', 'ffprobe.exe')
        if not all((TOOLS / name).is_file() for name in binaries):
            archive = work / 'ffmpeg-release-essentials.zip'
            fetch(FFMPEG + archive.name, archive)
            verify(archive, FFMPEG + archive.name + '.sha256')
            unpack(archive, work, *binaries)
            for name in binaries:
                (work / name).replace(TOOLS / name)


if __name__ == '__main__':
    main()
