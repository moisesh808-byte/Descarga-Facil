# Gestor Personal — prototipo 0.1

Prototipo funcional para Windows 11. **No es todavía un reemplazo completo de IDM.** Descarga archivos HTTP/HTTPS directos, con captura experimental de descargas en Chrome/Edge mediante extensión MV3. La detección de videos incrustados, aceleración por segmentos, pausa/reanudación, empaquetado EXE y notificaciones nativas están pendientes. El ajuste "detectar videos" se guarda pero aún no ejecuta detección.

## Iniciar
1. Instala Python 3.10+ en Windows.
2. Ejecuta `python app/main.py` desde la carpeta del proyecto. No requiere paquetes Python adicionales.
3. En Chrome abre `chrome://extensions`, activa **Modo desarrollador**, elige **Cargar descomprimida** y selecciona la carpeta `extension`. En Edge usa `edge://extensions`.
4. En opciones de la extensión pega el token que aparece en `%APPDATA%\GestorPersonal\bridge_token.txt` (archivo creado al iniciar la app).
5. Prueba primero con un archivo público pequeño descargable por URL directa. Puedes usar el menú contextual de un enlace: **Descargar enlace con Gestor Personal**.

## Precauciones y límites
- La captura automática está activada por defecto. Desactívala en Ajustes si una página falla; Chrome puede haber iniciado parcialmente una descarga antes de cancelarla.
- Solo enlaces públicos HTTP/HTTPS; archivos que requieren cookies, cabeceras especiales o sesión iniciada pueden fallar.
- El navegador no permite interceptar todos los tipos de descargas ni reproducir exactamente el comportamiento de IDM.
- Este prototipo escucha solo en `127.0.0.1` y requiere token; no compartas el token. Para una versión final se recomienda Native Messaging y validación reforzada de URLs.
- No descarga contenidos protegidos con DRM ni evita restricciones de acceso.
- No se inicia con Windows (desactivado por defecto); el interruptor aparece inhabilitado.
- El progreso no incluye pausa/reanudación; la aplicación debe permanecer abierta.


## v0.2 — Elegir dónde descargar
La extensión pregunta mediante una notificación de Edge: **Descarga Fácil** o **Normal con Edge**. Si no elegís en 60 segundos, la descarga continúa en Edge. En Windows activá las notificaciones de Edge para ver la pregunta. La aplicación de escritorio conserva la carpeta `%APPDATA%\GestorPersonal` y el token anterior, para no romper tu conexión.

**Actualización:** cerrá Edge y la app si hace falta, reemplazá los archivos de la carpeta `extension`, abrí `edge://extensions` y presioná **Recargar** en la extensión (o cargá esta nueva carpeta como descomprimida, quitando la anterior). No hace falta volver a introducir el token si recargás la misma extensión.
